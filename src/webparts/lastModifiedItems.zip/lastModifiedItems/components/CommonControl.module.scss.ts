/* tslint:disable */
require("./CommonControl.module.css");
const styles = {
  dataLabel: 'dataLabel_b9c45acf',
  pivotControl: 'pivotControl_b9c45acf',
  centerDiv: 'centerDiv_b9c45acf',
  resetFilter: 'resetFilter_b9c45acf',
  topBarFilters: 'topBarFilters_b9c45acf',
  secTitleContainer: 'secTitleContainer_b9c45acf',
  title: 'title_b9c45acf',
  content: 'content_b9c45acf',
  fileiconDiv: 'fileiconDiv_b9c45acf',
  pageLink: 'pageLink_b9c45acf',
  chartContainer: 'chartContainer_b9c45acf',
  chart: 'chart_b9c45acf',
  chartPerf: 'chartPerf_b9c45acf',
  textWithIcon: 'textWithIcon_b9c45acf',
  dataList: 'dataList_b9c45acf',
  tblHeadings: 'tblHeadings_b9c45acf',
  leftsec: 'leftsec_b9c45acf',
  'ms-Label': 'ms-Label_b9c45acf',
  'ms-SearchBox': 'ms-SearchBox_b9c45acf',
  Checkbox: 'Checkbox_b9c45acf'
};

export default styles;
/* tslint:enable */