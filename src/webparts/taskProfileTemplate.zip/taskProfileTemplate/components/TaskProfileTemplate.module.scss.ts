/* tslint:disable */
require("./TaskProfileTemplate.module.css");
const styles = {
  taskProfileTemplate: 'taskProfileTemplate_abd9c26c',
  teams: 'teams_abd9c26c',
  welcome: 'welcome_abd9c26c',
  welcomeImage: 'welcomeImage_abd9c26c',
  links: 'links_abd9c26c'
};

export default styles;
/* tslint:enable */